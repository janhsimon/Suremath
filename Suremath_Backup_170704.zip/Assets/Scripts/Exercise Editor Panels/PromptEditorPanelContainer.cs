﻿using UnityEngine;

public class PromptEditorPanelContainer : MonoBehaviour
{
	[SerializeField]
	GameObject newExerciseEditorPanelPrefab, textPromptEditorPanelPrefab, valuePromptEditorPanelPrefab, pointPromptEditorPanelPrefab;

	void Start()
	{
		AddNewExerciseEditorPanel();
	}

	void RemoveNewExerciseEditorPanel()
	{
		if (transform.childCount > 0)
		{
			Destroy(transform.GetChild(transform.childCount - 1).gameObject);
		}
	}

	void AddNewExerciseEditorPanel()
	{
		Instantiate(newExerciseEditorPanelPrefab, transform);
	}

	public void AddTextPromptEditorPanel()
	{
		RemoveNewExerciseEditorPanel();
		Instantiate(textPromptEditorPanelPrefab, transform);
		AddNewExerciseEditorPanel();
	}

	public void RemovePanel(GameObject panel)
	{
		Destroy(panel);
	}

	public void AddValuePromptEditorPanel()
	{
		RemoveNewExerciseEditorPanel();
		Instantiate(valuePromptEditorPanelPrefab, transform);
		AddNewExerciseEditorPanel();
	}

	public void AddPointPromptEditorPanel()
	{
		RemoveNewExerciseEditorPanel();
		Instantiate(pointPromptEditorPanelPrefab, transform);
		AddNewExerciseEditorPanel();
	}

	public void ClearAllPanels()
	{
		for (int i = transform.childCount - 1; i >= 0; i--)
		{
			Destroy(transform.GetChild(i).gameObject);
		}

		AddNewExerciseEditorPanel();
	}

	public string PanelsToString()
	{
		string output = "";

		for (int i = 0; i < transform.childCount; i++)
		{
			GameObject childGameObject = transform.GetChild(i).gameObject;

			TextPromptEditorPanel textPromptEditorPanel = childGameObject.GetComponent<TextPromptEditorPanel>();
			
			if (textPromptEditorPanel != null)
			{
				output += "<prompt type=\"text\">";
				output += textPromptEditorPanel.promptTextInputField.text;
				output += "</prompt>";
				continue;
			}

			ValuePromptEditorPanel valuePromptEditorPanel = childGameObject.GetComponent<ValuePromptEditorPanel>();

			if (valuePromptEditorPanel != null)
			{
				output += "<prompt type=\"value\" solution=\"" + valuePromptEditorPanel.solutionInputField.text + "\">";
				output += valuePromptEditorPanel.promptTextInputField.text;
				output += "</prompt>";
				continue;
			}

			PointPromptEditorPanel pointPromptEditorPanel = childGameObject.GetComponent<PointPromptEditorPanel>();

			if (pointPromptEditorPanel != null)
			{
				output += "<prompt type=\"point\" solution_x=\"" + pointPromptEditorPanel.solutionXInputField.text + "\" solution_y=\"" + pointPromptEditorPanel.solutionYInputField.text + "\">";
				output += pointPromptEditorPanel.promptTextInputField.text;
				output += "</prompt>";
			}
		}

		return output;
	}
}
