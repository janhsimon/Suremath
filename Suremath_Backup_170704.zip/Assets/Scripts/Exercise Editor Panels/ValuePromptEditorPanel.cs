﻿using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(LayoutElement))]
public class ValuePromptEditorPanel : MonoBehaviour
{
	public InputField promptTextInputField;
	public InputField solutionInputField;

	PromptEditorPanelContainer promptEditorPanelContainer;
	LayoutElement layoutElement;

	void Start()
	{
		Transform parent = transform.parent;
		promptEditorPanelContainer = parent.GetComponent<PromptEditorPanelContainer>();

		layoutElement = GetComponent<LayoutElement>();

		// TODO: dirty hack but seems necessary for resolution-independent layout
		RectTransform rectTransform = GetComponent<RectTransform>();
		rectTransform.localScale = new Vector2(1f, 1f);
	}

	void Update()
	{
		// make sure the prompt panel is always large enough for the text
		// and the 5px border over and under it
		Text text = promptTextInputField.GetComponentInChildren<Text>();
		layoutElement.minHeight = Mathf.Abs(text.preferredHeight) + 30f + 40f;
	}

	public void DeleteButtonClicked()
	{
		promptEditorPanelContainer.RemovePanel(gameObject);
	}
}
