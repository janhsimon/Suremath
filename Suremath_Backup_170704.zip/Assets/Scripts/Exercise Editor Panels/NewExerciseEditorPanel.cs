﻿using UnityEngine;

public class NewExerciseEditorPanel : MonoBehaviour
{
	PromptEditorPanelContainer promptEditorPanelContainer;

	void Start()
	{
		promptEditorPanelContainer = transform.parent.GetComponent<PromptEditorPanelContainer>();
		
		// TODO: dirty hack but seems necessary for resolution-independent layout
		RectTransform rectTransform = GetComponent<RectTransform>();
		rectTransform.localScale = new Vector2(1f, 1f);
	}

	public void NewTextPromptButtonClicked()
	{
		promptEditorPanelContainer.AddTextPromptEditorPanel();
	}

	public void NewValuePromptButtonClicked()
	{
		promptEditorPanelContainer.AddValuePromptEditorPanel();
	}

	public void NewPointPromptButtonClicked()
	{
		promptEditorPanelContainer.AddPointPromptEditorPanel();
	}
}
